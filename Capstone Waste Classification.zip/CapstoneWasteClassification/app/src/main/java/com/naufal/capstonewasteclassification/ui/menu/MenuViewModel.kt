package com.naufal.capstonewasteclassification.ui.menu

import androidx.lifecycle.ViewModel

class MenuViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}